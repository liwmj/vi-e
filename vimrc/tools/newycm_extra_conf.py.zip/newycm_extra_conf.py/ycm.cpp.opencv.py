# NOTE since the opencv2 library will be installed in the standard include path (e.g. /usr/include)
#      So there is no need to inject external flags here
