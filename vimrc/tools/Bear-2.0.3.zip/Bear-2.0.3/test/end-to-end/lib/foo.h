#ifndef foo_h
#define foo_h

namespace acme
{

void t1();

}

#endif
