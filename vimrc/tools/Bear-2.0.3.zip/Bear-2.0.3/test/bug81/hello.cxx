#include <cstdio>

EXPORT void foo(void) {
  printf("Hello world!\n");
}

int main() {
  foo();
}
